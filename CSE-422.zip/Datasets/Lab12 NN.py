# Create your first MLP in Keras
from keras.models import Sequential
from keras.layers import Dense
import numpy
import pandas as pd
# fix random seed for reproducibility
numpy.random.seed(7)
# load pima indians dataset
#X, Y = load_iris(return_X_y=True)

data = pd.read_csv("iris.csv")

data['species'] = data['species'].map({'setosa': 0, 'versicolor': 1, 'virginica': 2})

predictors = ['sepal_length', 'sepal_width','petal_length','petal_width']
X = data[predictors]
Y = data.species

# split into input (X) and output (Y) variables
#X = dataset[:,0:4]
#Y = dataset[:,4]
# create model
model = Sequential()
model.add(Dense(12, input_dim=4, activation='relu'))
model.add(Dense(8, activation='relu'))
model.add(Dense(1, activation='sigmoid'))
# Compile model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
# Fit the model
model.fit(X, Y, epochs=150, batch_size=10)
# evaluate the model
scores = model.evaluate(X, Y)
print("\n%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
